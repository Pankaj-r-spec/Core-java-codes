/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**
 *Program to find string is pallindrome or not
 * it works for small and capital letter both.
 * @author Pankaj
 */
public class StringPallindrome 
{
 public static void main(String[] args)
 {
  System.out.println("Is BOB is a pallindrome="+isPallindrome("BOB"));
  System.out.println("Is BOb is a pallindrome="+isPallindrome("BOb"));
  System.out.println("Is cat is a pallindrome="+isPallindrome("cat"));
 }
 
 public static String isPallindrome(String text)
 {
     String reverse = reverseString(text);
        if(text.equals(reverse))
        {
         return ("Yes it is a Pallindrome");
        }
        else if(text.equalsIgnoreCase(reverse))
        {
         return (" Yes it is a pallindrome But characters are small and capital");
         
        }
        else
        {
         return ("Not a Pallindrome ");
        }
 }        
 
 public static String reverseString(String input)
 {
     if(input==null || input.isEmpty())
     {
      return input;
     }
     
     return input.charAt(input.length()-1)+reverseString(input.substring(0, input.length()-1));
 }
}
