/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**
 *To Check given is pallindrome or not 
 * ex BOB 
 * @author Pankaj
 */
public class StringPallindromeUsingArray
{
  public static void main(String[] args)
 {
  System.out.println("Is BOB is a pallindrome="+reverseString("BOB"));
  System.out.println("Is BOb is a pallindrome="+reverseString("BOb"));
  System.out.println("Is cat is a pallindrome="+reverseString("cat"));
 }
 
 
 
 public static boolean reverseString(String input)
 {
     if(input==null || input.isEmpty())
     {
      return false;
     }
     else
     {
     char[] buffer = input.toCharArray();
     StringBuilder sb = new StringBuilder();
     
     for(int i=input.length()-1;i>=0;i--)
     {
      sb.append(buffer[i]);
     }
      String reverse = sb.toString();
      return input.equalsIgnoreCase(reverse);
      
     }
}
}
  

