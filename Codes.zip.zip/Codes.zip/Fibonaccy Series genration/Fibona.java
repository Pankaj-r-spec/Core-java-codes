/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**
 * code to genarate fibonaccy series
 * @author Pankaj
 */
public class Fibona 
{
    public static void main(String[] args) 
    {
        int first=0,second=1,sum=0;
      while(sum<=100)
      {
        System.out.println(first+" ");
        first=second;
        second=sum;
        sum=first+second;
      }
        
    }
    
}
