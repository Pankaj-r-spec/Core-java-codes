/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**
 *
 * @author Pankaj
 */
public class RemoveWhiteSpaces 
{
    public static void main(String[] args)
    {
      String s = "HELLO I AM               PANKAJ";
      System.out.println("Before removing white spaces...."+s);
      
      String s2= s.replaceAll("\\s", "");
      System.out.println("After removing white spaces...."+s2);
    }
    
}
