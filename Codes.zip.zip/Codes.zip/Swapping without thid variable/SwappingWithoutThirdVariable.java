/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**
 *swapping of two numbers without third variable
 * @author Pankaj
 */
public class SwappingWithoutThirdVariable
{
    public static void main(String[] args) 
    {
        int x=10,y=20,sum=0;
        System.out.println("Before Swapping");
        System.out.println("x="+x);
        System.out.println("y="+y);
            sum=x+y;  //sum=10+20=30
       
            x=sum-x;  //x=30-10=20
            y=sum-x;  //30-20=10
        System.out.println("After Swapping");
        System.out.println("x="+x);
        System.out.println("y="+y);    

    }
    
}
