/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Interview.Codes;

/**to find second highest number in array
 *
 * @author Pankaj
 */
public class SecondHighestInArray
{
    public static void main(String[] args) 
    {
      int[] arr={100,50,200,56,300,500};
      int largest=0;
      int secondlargest=0;
        for (int i = 0; i < arr.length; i++)
        {
            if(arr[i]>largest)
            {
                secondlargest=largest;
                largest=arr[i];
                        
            }
            else if(arr[i]>secondlargest)
                    {
                    secondlargest=arr[i];
                    }
              
        }
        System.out.println("largest number ="+largest);
        System.out.println("Second largest number="+secondlargest);
      
    }
    
}
